package kr.human.tw.vo;

import java.util.Date;
import java.util.List;

import lombok.Data;
@Data
public class FreeBoardVO {
	private int free_idx;
	private String nick;
	private String password;
	private String subject;
	private String content;
	private Date regDate;
	private int clickCount;
	private int likeCount;
	private String mode;
	
	// 댓글의 정보를 저장할 변수를 추가하자!!!
	private int commentCount; // 목록보기에서는 갯수만 필요
	private List<FreeCommentVO> commentList; // 내용보기에서는 댓글들이 모두 필요
	}

/*
CREATE SEQUENCE free_idx_seq;
CREATE TABLE freeBoard(
	free_idx NUMBER PRIMARY KEY,
	nick varchar2(50) NOT NULL,
	password varchar2(50) NOT NULL,
	subject varchar2(200) NOT NULL,
	content varchar2(5000) NOT NULL,
	regDate DATE default SYSDATE,
	clickCount NUMBER,
	likeCount NUMBER
);



 */