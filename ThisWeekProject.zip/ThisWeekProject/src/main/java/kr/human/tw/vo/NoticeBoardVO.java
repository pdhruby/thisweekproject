package kr.human.tw.vo;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class NoticeBoardVO {
	private int notice_idx;
	private String id;
	private String subject;
	private String content;
	private Date regDate;
	private int clickCount;
	private int likeCount;
	
	private int mode;
	private List<UpFileVO> fileList;

	// 댓글의 정보를 저장할 변수 추가
	private int noticecommentCount;	// 목록보기 갯수
	private List<NoticeCommentVO> noticecommentList;	// 내용보기에서는 댓글 필요
}
