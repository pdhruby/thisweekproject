package kr.human.tw.vo;

import lombok.Data;

/*


CREATE TABLE likeCheck(
	like_idx number PRIMARY KEY,
	board_idx number NOT NULL,
	id varchar2(50) NOT NULL,
	Whether char(1)  -- Y가 있느냐 없느냐만 체크
);

 */

@Data
public class LikeCheckVO {
	private int like_idx;
	private int board_idx;
	private String id;
	private int Whether;
	
	
}
