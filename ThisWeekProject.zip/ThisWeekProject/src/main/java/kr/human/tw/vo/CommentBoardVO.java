package kr.human.tw.vo;

import java.util.Date;
import java.util.List;

import lombok.Data;
/*


CREATE TABLE twboard(
	board_idx NUMBER PRIMARY KEY,
	category varchar2(100) check(category IN ('free', 'travel', 'restaurant', 'sport')) NOT NULL,
	password varchar2(100) NOT NULL,
	subject varchar2(100) NOT NULL,
	content varchar2(3000) NOT NULL,
	address varchar2(200) NOT NULL,
	clickCount NUMBER,
	likeCount NUMBER,
	commentCount NUMBER,
	regDate timestamp DEFAULT SYSDATE,
	user_idx NUMBER
);
*/
/*
CREATE TABLE user_info(
	user_idx NUMBER PRIMARY KEY,
	id varchar2(50) NOT NULL UNIQUE,
	password varchar2(50) NOT NULL,
	name varchar2(50) NOT NULL,
	birth DATE NOT NULL,
	gender char(1) NOT NULL check(gender IN ('M', 'F')),
	email varchar2(50) NOT NULL,
	phone varchar2(20) NOT NULL,
	postCode varchar2(10) NOT NULL,
	addr1 varchar2(200) NOT NULL,
	addr2 varchar2(200) NOT NULL,
	use NUMBER check(use IN (0,1,2,3,4,5,6,7,8,9)),
	lev NUMBER check(lev IN (0,1,2,3,4,5,6,7,8,9)),
	point NUMBER DEFAULT 1000
);

*/


/*
DROP SEQUENCE upfile_idx_seq;
CREATE SEQUENCE upfile_idx_seq;
DROP TABLE upfile;
CREATE TABLE upfile(
	file_idx NUMBER PRIMARY KEY,
	board_idx NUMBER NOT NULL, -- 원본글번호
	user_idx NUMBER NOT NULL,
	ofileName varchar2(100) NOT NULL, -- 원본 파일명
	sfileName varchar2(100) NOT NULL  -- 저장 파일명
);

*/
/*
CREATE TABLE commentboard(
	comment_idx NUMBER PRIMARY KEY,
	board_idx NUMBER NOT NULL,
	user_idx NUMBER NOT NULL,
	content varchar2(200) NOT NULL,
	regDate	timestamp DEFAULT sysdate,
	category varchar2(100) NOT NULL check(category IN ('free', 'travel', 'restaurant', 'sport'))
);
 */
@Data
public class CommentBoardVO {
	private int comment_idx;
	private int board_idx;
	private int user_idx;
	private String id;
	private String content;
	private Date   regDate;
	private String category;
	
	private String mode;
}
