package kr.human.tw.vo;

import java.util.Date;

import lombok.Data;


@Data
public class InquiryCommentBoardVO {
	private int inquiry_comment_idx;
	private int inquiry_idx;
	private String id;
	private String content;
	private int user_idx;
	private Date regDate;
	
	
	private String mode;
}
