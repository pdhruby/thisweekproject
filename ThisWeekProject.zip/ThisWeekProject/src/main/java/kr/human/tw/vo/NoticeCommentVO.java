package kr.human.tw.vo;

import java.util.Date;

import lombok.Data;
@Data
public class NoticeCommentVO {
	private int nc_idx;
	private int notice_idx;
	private String id;
	private String content;
	private Date regDate;
	private int likeCount;
	
	private String mode;
}
