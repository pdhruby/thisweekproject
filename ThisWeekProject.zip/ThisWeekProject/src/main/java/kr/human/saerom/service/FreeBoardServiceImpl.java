package kr.human.saerom.service;


import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.mybatis.MybatisApp;
import kr.human.saerom.dao.FreeBoardDAO;
import kr.human.saerom.dao.FreeBoardDAOImpl;
import kr.human.saerom.dao.FreeCommentDAO;
import kr.human.saerom.dao.FreeCommentDAOImpl;
import kr.human.tw.vo.FreeBoardVO;
import kr.human.tw.vo.FreeCommentVO;
import kr.human.tw.vo.PagingVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FreeBoardServiceImpl implements FreeBoardService{
	//---싱글톤
	private static FreeBoardService instance = new FreeBoardServiceImpl();
	private FreeBoardServiceImpl() {}
	public static FreeBoardService getInstance() {return instance; }
	//--------------------------------
	@Override
	public FreeBoardVO selectByIdx(int free_idx) {
		log.info("FreeBoardServiceImpl -> selectByIdx 호출 :"+free_idx);
		FreeBoardVO freeBoardVO = null;
		SqlSession sqlSession = null;
		FreeBoardDAO freeBoardDAO=null;	
		FreeCommentDAO commentDAO =null; //-------------댓글 추가 . 
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			freeBoardDAO = FreeBoardDAOImpl.getInstance();
			commentDAO = FreeCommentDAOImpl.getInstance();//-----댓글추가. 
			//------------------------------------------
			// 1. 해당 글번호의 글을 가져온다.
			freeBoardVO = freeBoardDAO.selectByIdx(sqlSession, free_idx);
			freeBoardVO.setClickCount(freeBoardVO.getClickCount()+1); // 나의 조회수 증가
			freeBoardDAO.increment(sqlSession, free_idx); // DB의 조회수 증가
			
			if(freeBoardVO!=null) {//----댓글때문에 추가 시작. 
				freeBoardVO.setCommentList(commentDAO.selectList(sqlSession, freeBoardVO.getFree_idx()));
				freeBoardVO.setCommentCount(commentDAO.selectCount(sqlSession, freeBoardVO.getFree_idx()));
			}//--------------------------댓글 때문에 추가 끝. 
			
			//------------------------------------------	
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		return freeBoardVO;
	}

	@Override
	public PagingVO<FreeBoardVO> selectList(int currentPage, int pageSize, int blockSize) {
	log.info("FreeBoardServiceImpl-> selectList 호출 :"+currentPage+","+pageSize+","+blockSize);
		PagingVO<FreeBoardVO> pagingVO =null;
		SqlSession sqlSession = null;
		FreeBoardDAO freeBoardDAO=null;	
		FreeCommentDAO commentDAO=null;

		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			freeBoardDAO = FreeBoardDAOImpl.getInstance();
			commentDAO = FreeCommentDAOImpl.getInstance();
	
			//------------------------------------------
			//1. 전체갯수
			int totalCount = freeBoardDAO.selectCount(sqlSession);
			//2. 페이지 계산
			pagingVO =  new PagingVO<FreeBoardVO>(totalCount, currentPage, pageSize, blockSize);
			//3. 글목록 
			HashMap<String, Integer> map = new HashMap<>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			List<FreeBoardVO> list = freeBoardDAO.selectList(sqlSession, map);
			//글목록을 넣어준다. 
			for(FreeBoardVO vo: list) {
				vo.setCommentCount(commentDAO.selectCount(sqlSession, vo.getFree_idx()));
			}

			
			pagingVO.setList(list);	
			//------------------------------------------	
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		
		return pagingVO;
	}
	


	@Override
	public void update(FreeBoardVO freeBoardVO) {
	log.info("FreeBoardServiceImpl  update 호출 :"+freeBoardVO);
	SqlSession sqlSession = null;
	FreeBoardDAO freeBoardDAO=null;	
	try {
		sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
		freeBoardDAO = FreeBoardDAOImpl.getInstance();
		//------------------------------------------
		if(freeBoardVO!=null) {
			// 1. 해당 글번호의 글을 가져온다.
			FreeBoardVO dbVO =  freeBoardDAO.selectByIdx(sqlSession, freeBoardVO.getFree_idx());
				if(dbVO!=null && dbVO.getPassword().equals(freeBoardVO.getPassword())) {
					//2. 비밀번호 일치하면 수정. 
				freeBoardDAO.update(sqlSession, freeBoardVO);
				freeBoardVO.setClickCount(freeBoardVO.getClickCount()-1); // 나의 조회수 증가
			}
		}

		//------------------------------------------	
		sqlSession.commit();
	} catch (Exception e) {
		sqlSession.rollback();
		e.printStackTrace();
	}finally {
		sqlSession.close();
	}
		
	}

	@Override
	public void delete(FreeBoardVO freeBoardVO) {
	log.info(" FreeBoardServiceImpl  delete 호출 :"+freeBoardVO);	
	SqlSession sqlSession = null;
	FreeBoardDAO freeBoardDAO=null;	
//	FreeCommentDAO commentDAO=null;
	try {
		sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
		freeBoardDAO = FreeBoardDAOImpl.getInstance();
	//	commentDAO =FreeCommentDAOImpl.getInstance();
		//------------------------------------------
		if(freeBoardVO!=null) {
			// 1. 해당 글번호의 글을 가져온다.
			FreeBoardVO dbVO =  freeBoardDAO.selectByIdx(sqlSession, freeBoardVO.getFree_idx());
			log.info(" FreeBoardServiceImpl  dbVO 호출 :"+dbVO);	
				if(dbVO!=null && dbVO.getPassword().equals(freeBoardVO.getPassword())) {
				freeBoardDAO.delete(sqlSession, freeBoardVO.getFree_idx());
				
				}
		}
		//------------------------------------------	
		sqlSession.commit();
	} catch (Exception e) {
		sqlSession.rollback();
		e.printStackTrace();
	}finally {
		sqlSession.close();
	}
		
	}

	@Override
	public void insert(FreeBoardVO freeBoardVO) {
	log.info(" FreeBoardServiceImpl  insert 호출 :"+freeBoardVO);
	SqlSession sqlSession = null;
	FreeBoardDAO freeBoardDAO=null;	
	try {
		sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
		freeBoardDAO = FreeBoardDAOImpl.getInstance();
		//------------------------------------------
		if(freeBoardVO!=null) {
			freeBoardDAO.insert(sqlSession, freeBoardVO);
		}
		
		//------------------------------------------	
		sqlSession.commit();
	} catch (Exception e) {
		sqlSession.rollback();
		e.printStackTrace();
	}finally {
		sqlSession.close();
	}
		
	}

	@Override
	public void likeCount(int free_idx,boolean isClick) {
	log.info("FreeBoardServiceImpl  likeCount 호출 :"+free_idx);
	SqlSession sqlSession = null;
	FreeBoardDAO freeBoardDAO=null;	
	FreeBoardVO freeBoardVO=null;
	try {
		sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
		freeBoardDAO = FreeBoardDAOImpl.getInstance();
		//------------------------------------------
		freeBoardVO = freeBoardDAO.selectByIdx(sqlSession, free_idx);
			if(isClick) {
			freeBoardVO.setLikeCount(freeBoardVO.getLikeCount()+1); // 나의 추천수 증가
			freeBoardVO.setClickCount(freeBoardVO.getClickCount()-1); // 나의 조회수 증가
			freeBoardDAO.likeCount(sqlSession, free_idx); // DB의 조회수 증가
		
			}
		//------------------------------------------	
		sqlSession.commit();
	} catch (Exception e) {
		sqlSession.rollback();
		e.printStackTrace();
	}finally {
		sqlSession.close();
	}
		
	}

	
	//------------댓글 ------------------------------------
	@Override
	public void commentInsert(FreeCommentVO vo) {
		log.info("FreeBoardServiceImpl  commentInsert 호출 :"+vo);
		SqlSession sqlSession = null;
		FreeCommentDAO dao=null;	
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = FreeCommentDAOImpl.getInstance();
			//------------------------------------------
			if(vo!=null) {
				dao.insert(sqlSession, vo);
			}
			//------------------------------------------	
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
			
			
		
	}

	@Override
	public void commentUpdate(FreeCommentVO vo) {
		log.info("FreeBoardServiceImpl  commentUpdate 호출 :"+vo);
		SqlSession sqlSession = null;
		FreeCommentDAO dao=null;	
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = FreeCommentDAOImpl.getInstance();
			//------------------------------------------
			if(vo!=null) {
				FreeCommentVO dbvo=dao.selectByIdx(sqlSession, vo.getFc_idx());
				if(dbvo!=null && dbvo.getPassword().equals(vo.getPassword())) {
				dao.update(sqlSession, vo);
				}
			}
			//------------------------------------------	
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
			
		
		
	}

	@Override
	public void commentDelete(FreeCommentVO vo) {
		log.info("FreeBoardServiceImpl  commentUpdate 호출 :"+vo);
		SqlSession sqlSession = null;
		FreeCommentDAO dao=null;	
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			dao = FreeCommentDAOImpl.getInstance();
			//------------------------------------------
			if(vo!=null) {
				FreeCommentVO dbVO= dao.selectByIdx(sqlSession,vo.getFc_idx());
				if(dbVO!=null && dbVO.getPassword().equals(vo.getPassword())) {
					dao.delete(sqlSession, vo.getFc_idx());
				}
			}
			//------------------------------------------	
			sqlSession.commit();
		} catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		
	}
}


