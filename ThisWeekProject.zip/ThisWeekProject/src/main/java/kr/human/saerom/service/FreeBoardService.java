package kr.human.saerom.service;


import kr.human.tw.vo.FreeBoardVO;
import kr.human.tw.vo.FreeCommentVO;
import kr.human.tw.vo.PagingVO;

public interface FreeBoardService {
	//페이지 찍기
	PagingVO<FreeBoardVO> selectList(int currentPage, int pageSize, int blockSize);
	//내용보기
	FreeBoardVO selectByIdx(int free_idx);
	//수정 
	void update(FreeBoardVO freeBoardVO);
	//삭제 
	void delete(FreeBoardVO freeBoardVO);
	//저장
	void insert(FreeBoardVO freeBoardVO);
	//추천수
	void likeCount(int free_idx,boolean isClick);
	
	// 댓글 저장
	void commentInsert(FreeCommentVO freeCommentVO);
	// 댓글 수정
	void commentUpdate(FreeCommentVO freeCommentVO);
	// 댓글 삭제
	void commentDelete(FreeCommentVO freeCommentVO);
}
