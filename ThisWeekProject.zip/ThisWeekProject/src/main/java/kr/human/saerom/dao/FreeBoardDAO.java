package kr.human.saerom.dao;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.FreeBoardVO;



public interface FreeBoardDAO {
	// 전체 개수 얻기
	public int selectCount(SqlSession sqlSession) throws SQLException;
	// 1개 얻기
	public FreeBoardVO selectByIdx(SqlSession sqlSession, int free_idx) throws SQLException;
	// 1페이지 얻기
	public List<FreeBoardVO> selectList(SqlSession sqlSession,  HashMap<String, Integer> map) throws SQLException;
	// 저장
	public void insert(SqlSession sqlSession, FreeBoardVO freeVO) throws SQLException;
	// 수정
	public void update(SqlSession sqlSession, FreeBoardVO freeVO) throws SQLException;
	// 삭제
	public void delete(SqlSession sqlSession, int free_idx) throws SQLException;
	// 조회수 증가
	public void increment(SqlSession sqlSession, int free_idx) throws SQLException;
	//추천수증가
	public void likeCount(SqlSession sqlSession,int free_idx)throws SQLException;
	
}

