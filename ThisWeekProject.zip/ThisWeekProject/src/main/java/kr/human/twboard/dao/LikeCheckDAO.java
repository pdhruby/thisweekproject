package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.LikeCheckVO;

public interface LikeCheckDAO {
	
	// 1. 해당 글번호 와 id를 통해 불러오기 
	public int selectByidxAndid(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException;
	
	// 2. 저장 
	public void likeInsert(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException;
	
	// 3. 삭제 
	public void deleteByidxAndid(SqlSession sqlSession, LikeCheckVO likeCheckVO) throws SQLException;
	
	
}
