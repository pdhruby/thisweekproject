package kr.human.twboard.service;


import org.apache.ibatis.session.SqlSession;

import kr.human.mybatis.MybatisApp;
import kr.human.tw.vo.LikeCheckVO;
import kr.human.twboard.dao.LikeCheckDAO;
import kr.human.twboard.dao.LikeCheckDAOImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LikeCheckServiceImpl implements LikeCheckService{
	private static LikeCheckService instance = new LikeCheckServiceImpl();
	private LikeCheckServiceImpl() {}
	public static LikeCheckService getInstance() {
		return instance;
	}
	//------------------------------------------------------------------------------------------
	
	@Override
	public int selectWhether(int board_idx, String id) {
		log.info("LikeCheckServiceImpl selectWhether 호출 : " + board_idx + ", " + id);
		LikeCheckVO likeCheckVO= new LikeCheckVO();
		SqlSession sqlSession = null;
		LikeCheckDAO likeCheckDAO = null;
		int count = 0;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			likeCheckDAO = LikeCheckDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 넘겨받은 글번호와 id를 vo에 담아서 추천여부를 가져온다.
			// 0이면 추천한적이 없고, 0이 아니면 추천한 기록이 있다.
			likeCheckVO.setBoard_idx(board_idx);
			likeCheckVO.setId(id);
			count = likeCheckDAO.selectByidxAndid(sqlSession, likeCheckVO);
					
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------
		log.info("LikeCheckServiceImpl selectWhether 리턴 : " + count);
		return count;
	}
	@Override
	public void likeInsert(int board_idx, String id) {
		log.info("LikeCheckServiceImpl likeInsert 호출 : " + board_idx + ", " + id);
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		LikeCheckVO likeCheckVO = null;
		LikeCheckDAO likeCheckDAO = null;		
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			likeCheckDAO = LikeCheckDAOImpl.getInstance();
			likeCheckVO = new LikeCheckVO();
			//--------------------------------------------------------------------
			// 1. 넘겨받은 글번호 와 id를 vo에 저장
				if(board_idx > 0 && id != null && id.trim().length() > 0) {	// 글번호가 0 이상이면서 동시에 id가 null이 아니면서 길이가 0 초과일때
					likeCheckVO.setBoard_idx(board_idx);
					likeCheckVO.setId(id);
					// 2. vo에 담아서 dao로 쏜다.
					likeCheckDAO.likeInsert(sqlSession, likeCheckVO);
				}			
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------
		
	}
	@Override
	public void likeCancel(int board_idx, String id) {
		log.info("LikeCheckServiceImpl likeCancel 호출 : " + board_idx + ", " + id);
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		LikeCheckVO likeCheckVO = null;
		LikeCheckDAO likeCheckDAO = null;		
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			likeCheckDAO = LikeCheckDAOImpl.getInstance();
			likeCheckVO = new LikeCheckVO();
			//--------------------------------------------------------------------
			// 1. 넘겨받은 글번호 와 id를 vo에 저장
				if(board_idx > 0 && id != null && id.trim().length() > 0) {	// 글번호가 0 이상이면서 동시에 id가 null이 아니면서 길이가 0 초과일때
					likeCheckVO.setBoard_idx(board_idx);
					likeCheckVO.setId(id);
					// 2. vo에 담아서 delete 한다.
					likeCheckDAO.deleteByidxAndid(sqlSession, likeCheckVO);
				}			
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------
		
	}
	
	
}
