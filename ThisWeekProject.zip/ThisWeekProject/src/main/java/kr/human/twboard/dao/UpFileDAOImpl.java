package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.UpFileVO;

public class UpFileDAOImpl implements UpFileDAO{
	private static UpFileDAO instance = new UpFileDAOImpl();
	private UpFileDAOImpl() {
		;
	}
	public static UpFileDAO getInstance() {
		return instance;
	}
	//----------------------------------------------------------
	@Override
	public int selectCountByRef(SqlSession sqlSession, int board_idx) throws SQLException {
		return sqlSession.selectOne("upFile.selectCountByRef", board_idx);
	}
	@Override
	public List<UpFileVO> selectListByRef(SqlSession sqlSession, int board_idx) throws SQLException {
		return sqlSession.selectList("upFile.selectListByRef", board_idx);
	}
	@Override
	public void insert(SqlSession sqlSession, UpFileVO upFileVO) throws SQLException {
		sqlSession.insert("upFile.insert", upFileVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int file_idx) throws SQLException {
		sqlSession.delete("upFile.delete", file_idx);		
	}
	@Override
	public UpFileVO selectByIdx(SqlSession sqlSession, int file_idx) throws SQLException {
		return sqlSession.selectOne("upFile.selectByIdx", file_idx);
	}
	
}
