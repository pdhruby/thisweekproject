package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.UpFileVO;

public interface UpFileDAO {
	int selectCountByRef(SqlSession sqlSession, int board_idx) throws SQLException;
	List<UpFileVO> selectListByRef(SqlSession sqlSession,int board_idx) throws SQLException;
	void insert(SqlSession sqlSession,UpFileVO upFileVO) throws SQLException;
	void delete(SqlSession sqlSession, int file_idx) throws SQLException;
	UpFileVO selectByIdx(SqlSession sqlSession, int file_idx) throws SQLException;
}
