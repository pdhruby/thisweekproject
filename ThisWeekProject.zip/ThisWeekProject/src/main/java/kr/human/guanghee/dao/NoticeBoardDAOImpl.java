package kr.human.guanghee.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.NoticeBoardVO;




public class NoticeBoardDAOImpl implements NoticeBoardDAO{
	private static NoticeBoardDAO instance = new NoticeBoardDAOImpl();
	private NoticeBoardDAOImpl() {}
	public static NoticeBoardDAO getInstance() {
		return instance;
	}
	@Override
	public int selectCount(SqlSession sqlSession) throws SQLException {
		return sqlSession.selectOne("noticeBoard.selectCount");
	}
	@Override
	public NoticeBoardVO selectByIdx(SqlSession sqlSession, int notice_idx) throws SQLException {
		return sqlSession.selectOne("noticeBoard.selectByIdx",notice_idx);
	}
	@Override
	public List<NoticeBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
		return sqlSession.selectList("noticeBoard.selectList",map);
	}
	@Override
	public void insert(SqlSession sqlSession, NoticeBoardVO noticeBoardVO) throws SQLException {
		sqlSession.insert("noticeBoard.insert",noticeBoardVO);
	}
	@Override
	public void update(SqlSession sqlSession, NoticeBoardVO noticeBoardVO) throws SQLException {
		sqlSession.update("noticeBoard.update",noticeBoardVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int notice_idx) throws SQLException {
		sqlSession.delete("noticeBoard.delete",notice_idx);
	}
	@Override
	public void clickCountUp(SqlSession sqlSession, int notice_idx) throws SQLException {
		sqlSession.update("noticeBoard.clickCountUp",notice_idx);
	}
	@Override
	public void likeCountUp(SqlSession sqlSession, int notice_idx) throws SQLException {
		sqlSession.update("noticeBoard.likeCountUp",notice_idx);
	}
}
	