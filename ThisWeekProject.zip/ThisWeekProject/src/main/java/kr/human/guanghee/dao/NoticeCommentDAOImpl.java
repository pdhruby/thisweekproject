package kr.human.guanghee.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.NoticeCommentVO;



public class NoticeCommentDAOImpl implements NoticeCommentDAO{
	private static NoticeCommentDAO instance = new NoticeCommentDAOImpl();
	private NoticeCommentDAOImpl() {}
	public static NoticeCommentDAO getinstance() {
		return instance;
	}
	@Override
	public int selectCount(SqlSession sqlSession, int notice_idx) throws SQLException {
		return sqlSession.selectOne("noticeComment.selectCount",notice_idx);
	}
	@Override
	public List<NoticeCommentVO> selectList(SqlSession sqlSession, int notice_idx) throws SQLException {
		return sqlSession.selectList("noticeComment.selectList",notice_idx);
	}
	@Override
	public NoticeCommentVO selectByIdx(SqlSession sqlSession, int nc_idx) throws SQLException {
		return sqlSession.selectOne("noticeComment.selectByIdx", nc_idx);
	}
	@Override
	public void insert(SqlSession sqlSession, NoticeCommentVO noticeCommentVO) throws SQLException {
		sqlSession.insert("noticeComment.insert",noticeCommentVO);
	}
	@Override
	public void update(SqlSession sqlSession, NoticeCommentVO noticeCommentVO) throws SQLException {
		sqlSession.update("noticeComment.update",noticeCommentVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int nc_idx) throws SQLException {
		sqlSession.delete("noticeComment.delete",nc_idx);
		
	}
	@Override
	public void likeCountUp(SqlSession sqlSession, int nc_idx) throws SQLException {
		sqlSession.update("noticeComment.likeCountUp",nc_idx);
		
	}
	@Override
	public void deleteByRef(SqlSession sqlSession, int notice_idx) throws SQLException {
		sqlSession.delete("noticeComment.deleteByRef",notice_idx);
	}
}