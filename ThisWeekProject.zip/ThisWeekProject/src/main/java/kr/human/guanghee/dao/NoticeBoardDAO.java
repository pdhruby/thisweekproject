package kr.human.guanghee.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.NoticeBoardVO;




public interface NoticeBoardDAO {
	// 전체 개수 얻어오기
	int selectCount(SqlSession sqlSession) throws SQLException;
	
	// 게시글 한개 얻기
	NoticeBoardVO selectByIdx(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	//한 페이지 얻기
	List<NoticeBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException;
	
	//저장
	void insert(SqlSession sqlSession, NoticeBoardVO noticeBoardVO) throws SQLException;
	
	//수정
	void update(SqlSession sqlSession, NoticeBoardVO noticeBoardVO) throws SQLException;
	
	//삭제
	void delete(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	//조회수 증가
	public void clickCountUp(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	//추천수 증가
	public void likeCountUp(SqlSession sqlSession, int notice_idx) throws SQLException;
}
