package kr.human.guanghee.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.NoticeCommentVO;




public interface NoticeCommentDAO {
	
	//게시글 전체 댓글 갯수
	public int selectCount(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	//게시글 댓글 전체 가져오기
	public List<NoticeCommentVO> selectList(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	// 3. 1개 얻기
	public NoticeCommentVO selectByIdx(SqlSession sqlSession, int nc_idx) throws SQLException;
	
	//저장
	public void insert(SqlSession sqlSession,NoticeCommentVO noticeCommentVO) throws SQLException;
	
	//수정
	public void update(SqlSession sqlSession,NoticeCommentVO noticeCommentVO) throws SQLException;
	
	//삭제
	public void delete(SqlSession sqlSession,int nc_idx) throws SQLException;
	
	// 7. 지정 번호의 댓글 모두 지우기
	public void deleteByRef(SqlSession sqlSession, int notice_idx) throws SQLException;
	
	//추천수 증가
	public void likeCountUp(SqlSession sqlSession,int nc_idx) throws SQLException;
}
