package kr.human.daehyung.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.InquiryBoardVO;

public interface InquiryBoardDAO {

	// 전체개수 얻기
	int selectCount(SqlSession sqlSession) throws SQLException;
	
	//1개 얻기 (idx로)
	public InquiryBoardVO selectByIdx(SqlSession sqlSession, int idx) throws SQLException;
	
	// 1페이지 분량얻기(리스트로)
	public List<InquiryBoardVO> selectList(SqlSession sqlSession,HashMap<String, Integer> map) throws SQLException;
		
	// 저장
	public void insert(SqlSession sqlSession ,InquiryBoardVO inquiryBoardVO) throws SQLException;
	
	// 수정
	public void update(SqlSession sqlSession,InquiryBoardVO inquiryBoardVO) throws SQLException;
	
	// 삭제
	public void delete(SqlSession sqlSession, int idx) throws SQLException;
	
	// 조회수증가
	public void increment(SqlSession sqlSession, int board_idx) throws SQLException;
}
