package kr.human.daehyung.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import kr.human.tw.vo.InquiryBoardVO;

public class InquiryBoardDAOImpl implements InquiryBoardDAO {
		private static InquiryBoardDAO Instance = new InquiryBoardDAOImpl();
		private InquiryBoardDAOImpl() {}
		public static InquiryBoardDAO getInstance() {
			return Instance;
		}
		
		@Override
		public int selectCount(SqlSession sqlSession) throws SQLException {
			return sqlSession.selectOne("iqBoard.selectCount");
			
		}
		@Override
		public InquiryBoardVO selectByIdx(SqlSession sqlSession, int idx) throws SQLException {
			return sqlSession.selectOne("iqBoard.selectByIdx", idx);
		}
		@Override
		public List<InquiryBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
			return sqlSession.selectList("iqBoard.selectList", map);
		}
		@Override
		public void insert(SqlSession sqlSession, InquiryBoardVO inquiryBoardVO) throws SQLException {
			sqlSession.insert("iqBoard.insert", inquiryBoardVO);
		}
		@Override
		public void update(SqlSession sqlSession, InquiryBoardVO inquiryBoardVO) throws SQLException {
			sqlSession.update("iqBoard.update", inquiryBoardVO);
		}
		@Override
		public void delete(SqlSession sqlSession, int idx) throws SQLException {
			sqlSession.delete("iqBoard.delete", idx);
		}
		@Override
		public void increment(SqlSession sqlSession, int board_idx) throws SQLException {
			sqlSession.update("iqBoard.increment", board_idx);
			
		}

};
	
