package kr.human.daehyung.service;

import kr.human.tw.vo.InquiryBoardVO;
import kr.human.tw.vo.InquiryCommentBoardVO;
import kr.human.tw.vo.PagingVO;

public interface InquiryBoardService {

		//1.1개얻기 --- 내용보기 / 수정하기 / 삭제하기
		PagingVO<InquiryBoardVO> selectList(int currentPage, int pageSize, int blockSize);
		
		//2. 내용보기
		InquiryBoardVO selectByIdx(int inquiry_idx, boolean isClick);
		
		//3.저장
		void insert(InquiryBoardVO inquiryBoardVO);
	
		//4.수정
		void update(InquiryBoardVO inquiryBoardVO);
	
		//5.삭제
		void delete(InquiryBoardVO inquiryBoardVO);
		
		
	
		//6. 댓글 저장
		void commentInsert(InquiryCommentBoardVO inquiryCommentBoardVO);
		//7. 댓글 수정
		void commentUpdate(InquiryCommentBoardVO inquiryCommentBoardVO);
		//8. 댓글 삭제
		void commentDelete(InquiryCommentBoardVO inquiryCommentBoardVO);
}
