package kr.human.daehyung.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.InquiryCommentBoardVO;

public class InquiryCommentBoardDAOImpl implements InquiryCommentBoardDAO{
	private static InquiryCommentBoardDAO instance = new InquiryCommentBoardDAOImpl();
	private InquiryCommentBoardDAOImpl() {;}
	public static InquiryCommentBoardDAO getInstance() {
		return instance;
	}
		
	@Override
	public int selectCount(SqlSession sqlSession, int inquiry_idx) throws SQLException {
		return  sqlSession.selectOne("iqcomment.selectCount", inquiry_idx);
	}

	@Override
	public List<InquiryCommentBoardVO> selectList(SqlSession sqlSession, int inquiry_idx) throws SQLException {
		return sqlSession.selectList("iqcomment.selectList", inquiry_idx);
	}

	@Override
	public InquiryCommentBoardVO selectByIdx(SqlSession sqlSession, int inquiry_comment_idx) throws SQLException {
		return sqlSession.selectOne("iqcomment.selectByIdx",inquiry_comment_idx);
	}

	@Override
	public void insert(SqlSession sqlSession, InquiryCommentBoardVO inquiryCommentBoardVO) throws SQLException {
		sqlSession.insert("iqcomment.insert",inquiryCommentBoardVO);
	}

	@Override
	public void update(SqlSession sqlSession, InquiryCommentBoardVO inquiryCommentBoardVO) throws SQLException {
		sqlSession.update("iqcomment.update",inquiryCommentBoardVO);
		
	}

	@Override
	public void delete(SqlSession sqlSession, int inquiry_comment_idx) throws SQLException {
		sqlSession.delete("iqcomment.delete",inquiry_comment_idx);
		
	}

	@Override
	public void deleteByRef(SqlSession sqlSession, int inquiry_idx) throws SQLException {
		sqlSession.delete("iqcomment.deleteByRef",inquiry_idx);
	}
	
	
}
