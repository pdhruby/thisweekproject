package kr.human.daehyung.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.InquiryCommentBoardVO;

public interface InquiryCommentBoardDAO {
	
	// 1. 지정 번호의 댓글의 갯수 구하기
	public int selectCount(SqlSession sqlSession, int inquiry_idx) throws SQLException;
	
	// 2. 지정 번호의 댓글 리스트 구하기
	public List<InquiryCommentBoardVO> selectList(SqlSession sqlSession, int inquiry_idx) throws SQLException;
	
	// 3. 1개 얻기
	public InquiryCommentBoardVO selectByIdx(SqlSession sqlSession, int inquiry_comment_idx) throws SQLException;
	
	// 4. 저장
	public void insert(SqlSession sqlSession, InquiryCommentBoardVO inquiryCommentBoardVO) throws SQLException; 
	
	// 5. 수정
	public void update(SqlSession sqlSession,InquiryCommentBoardVO inquiryCommentBoardVO) throws SQLException;
	
	// 6. 삭제
	public void delete(SqlSession sqlSession, int inquiry_comment_idx) throws SQLException;
	
	// 7. 지정 번호의 댓글 모두 지우기
	public void deleteByRef(SqlSession sqlSession, int inquiry_idx) throws SQLException;
}
